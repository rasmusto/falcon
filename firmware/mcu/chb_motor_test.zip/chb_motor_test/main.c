#define F_CPU 32000000UL
#include <stdlib.h>
#include <inttypes.h>
#include <stdio.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "avr_compiler.h"
#include "clksys_driver.h"
#include "usart_driver.h"
#include "TC_driver.h"
#include "hires_driver.h"
#include "awex_driver.h"
#include "adc_driver.h"

#define STARTUP_LOCK_TIME 1000
#define STARTUP_PWM 200
#define TRANSITION_VOLTAGE

#define SET_phaseOutputsEHigh(value) phaseOutputsEHigh = (value); phaseOutputsEHighInv = (uint8_t)(~(value))
#define SET_phaseOutputsELow(value) phaseOutputsELow = (value); phaseOutputsELowInv = (uint8_t)(~(value))
#define SET_phaseOutputsFHigh(value) phaseOutputsFHigh = (value); phaseOutputsFHighInv = (uint8_t)(~(value))
#define SET_phaseOutputsFLow(value) phaseOutputsFLow = (value); phaseOutputsFLowInv = (uint8_t)(~(value))
#define SET_phaseOutputsDHigh(value) phaseOutputsDHigh = (value); phaseOutputsDHighInv = (uint8_t)(~(value))
#define SET_phaseOutputsDLow(value) phaseOutputsDLow = (value); phaseOutputsDLowInv = (uint8_t)(~(value))

#define SET_PHASE_STATE_1_MOT2() \
	SET_phaseOutputsEHigh(phaseOutputsEHigh & 0b01111111); \
	SET_phaseOutputsEHigh(phaseOutputsEHigh | 0b01000000);  /* set bits 6-7 of phaseOutputsEHigh to 01 */ \
															\
	SET_phaseOutputsELow(phaseOutputsELow & 0b10111111); \
	SET_phaseOutputsELow(phaseOutputsELow | 0b10000000); /* and 10 for phaseOutputsELow */ \
															\
	SET_phaseOutputsFHigh(phaseOutputsFHigh & 0b11110000); /* set bits 0-3 of phaseOutputsFHigh and phaseOutputsFLow to 0 */ \
	SET_phaseOutputsFLow(phaseOutputsFLow & 0b11110000); \
															\
	PORTF.OUT &= 0b11110010; /* set b2 floating -- important to do this in this order to avoid shoot through!! (and set c2 floating)  */ \
	PORTF.OUT |= 0b00000010; /* set b2 low */

#define SET_PHASE_STATE_2_MOT2() \
	SET_phaseOutputsEHigh(phaseOutputsEHigh & 0b01111111); \
	SET_phaseOutputsEHigh(phaseOutputsEHigh | 0b01000000); \
															\
	SET_phaseOutputsELow(phaseOutputsELow & 0b10111111); \
	SET_phaseOutputsELow(phaseOutputsELow | 0b10000000); \
															\
	SET_phaseOutputsFHigh(phaseOutputsFHigh & 0b11110000); \
	SET_phaseOutputsFLow(phaseOutputsFLow & 0b11110000); \
															\
	PORTF.OUT &= 0b11111000; /* set c2 floating -- important to do this in this order to avoid shoot through!! (and set b2 floating) */ \
	PORTF.OUT |= 0b00001000; /* set c2 low */
	

#define SET_PHASE_STATE_3_MOT2() \
	SET_phaseOutputsEHigh(phaseOutputsEHigh & 0b00111111); \
	SET_phaseOutputsELow(phaseOutputsELow & 0b00111111); \
															\
	SET_phaseOutputsFHigh(phaseOutputsFHigh & 0b11110001); \
	SET_phaseOutputsFHigh(phaseOutputsFHigh | 0b00000001); \
															\
	SET_phaseOutputsFLow(phaseOutputsFLow & 0b11110010); \
	SET_phaseOutputsFLow(phaseOutputsFLow | 0b00000010); \
															\
	PORTF.OUT &= 0b11111011; /* set c2 floating -- important to do this in this order to avoid shoot through!! */ \
	PORTF.OUT |= 0b00001000; /* set c2 low */ \
															\
	PORTE.OUT &= 0b00111111; /* set a2 floating */

#define SET_PHASE_STATE_4_MOT2() \
	SET_phaseOutputsEHigh(phaseOutputsEHigh & 0b00111111); \
	SET_phaseOutputsELow(phaseOutputsELow & 0b00111111); \
															\
	SET_phaseOutputsFHigh(phaseOutputsFHigh & 0b11110001); \
	SET_phaseOutputsFHigh(phaseOutputsFHigh | 0b00000001); \
															\
	SET_phaseOutputsFLow(phaseOutputsFLow & 0b11110010); \
	SET_phaseOutputsFLow(phaseOutputsFLow | 0b00000010); \
															\
	PORTE.OUT &= 0b10111111; /* set a2 floating -- important to do this in this order to avoid shoot through!! */ \
	PORTE.OUT |= 0b10000000; /* set a2 low */ \
															\
	PORTF.OUT &= 0b11110011; /* set c2 floating */

#define SET_PHASE_STATE_5_MOT2() \
	SET_phaseOutputsEHigh(phaseOutputsEHigh & 0b00111111); \
	SET_phaseOutputsELow(phaseOutputsELow & 0b00111111); \
															\
	SET_phaseOutputsFHigh(phaseOutputsFHigh & 0b11110100); \
	SET_phaseOutputsFHigh(phaseOutputsFHigh | 0b00000100); \
															\
	SET_phaseOutputsFLow(phaseOutputsFLow & 0b11111000); \
	SET_phaseOutputsFLow(phaseOutputsFLow | 0b00001000); \
															\
	PORTE.OUT &= 0b10111111; /* set a2 floating -- important to do this in this order to avoid shoot through!! */ 	\
	PORTE.OUT |= 0b10000000; /* set a2 low */			\
															\
	PORTF.OUT &= 0b11111100; /* set b2 floating */

#define SET_PHASE_STATE_6_MOT2() \
	SET_phaseOutputsEHigh(phaseOutputsEHigh & 0b00111111); \
	SET_phaseOutputsELow(phaseOutputsELow & 0b00111111); \
															\
	SET_phaseOutputsFHigh(phaseOutputsFHigh & 0b11110100); \
	SET_phaseOutputsFHigh(phaseOutputsFHigh | 0b00000100); \
															\
	SET_phaseOutputsFLow(phaseOutputsFLow & 0b11111000); \
	SET_phaseOutputsFLow(phaseOutputsFLow | 0b00001000); \
															\
	PORTF.OUT &= 0b11111110; /* set b2 floating -- important to do this in this order to avoid shoot through!! */ \
	PORTF.OUT |= 0b00000010; /* set b2 low */ \
															\
	PORTE.OUT &= 0b00111111; /* set a2 floating */

// map putchar to mystdout for use with printf (stdout needs to be set to &debug in main)
static int putcharDebug (char c, FILE *stream);
static void initUarts (void);
static FILE debug = FDEV_SETUP_STREAM (putcharDebug, NULL, _FDEV_SETUP_WRITE);

void configClock (void);
void initUarts (void);
void configPWM (volatile TC0_t * tc, HIRES_t * hires, uint16_t period);
void configDelayTimer (volatile TC0_t * tc);
void setPwmA (volatile TC0_t* tc, uint16_t duty);
void setPwmB (volatile TC0_t* tc, uint16_t duty);
void setPwmC (volatile TC0_t* tc, uint16_t duty);
uint8_t initAdc (ADC_t * adc);

volatile uint8_t adcOffsetA;
volatile uint8_t adcOffsetB;

volatile uint8_t senseValues[12];
volatile uint8_t samplingGroup;

volatile uint8_t motor1State = 0;
volatile uint8_t motor2State = 0;
volatile uint8_t motor3State = 0;
volatile uint8_t motor4State = 0;

// 0 = falling
// 1 = rising
volatile uint8_t stateSlope[6] = {0,1,0,1,0,1}; // slope of back emf for each state
volatile uint8_t motor2StateSenseIndex[6] = {5,4,3,5,4,3}; // index in senseValues for each phase

volatile uint8_t motor1Thresh = 0;
volatile uint8_t motor2Thresh = 0;
volatile uint8_t motor3Thresh = 0;
volatile uint8_t motor4Thresh = 0;

volatile uint8_t phaseOutputsEHigh = 0; // keep track of which pins should be driven high during high part of pwm
volatile uint8_t phaseOutputsFHigh = 0; // keep track of which pins should be driven high during high part of pwm
volatile uint8_t phaseOutputsDHigh = 0; // keep track of which pins should be driven high during high part of pwm

volatile uint8_t phaseOutputsELow = 0; // keep track of which pins should be driven high during low part of pwm
volatile uint8_t phaseOutputsFLow = 0; // keep track of which pins should be driven high during low part of pwm
volatile uint8_t phaseOutputsDLow = 0; // keep track of which pins should be driven high during low part of pwm

// always store inverted versions of above 6 variables to reduce computations that have to be done ever pwm cycle

volatile uint8_t phaseOutputsEHighInv = 0; // keep track of which pins should be driven high during high part of pwm
volatile uint8_t phaseOutputsFHighInv = 0; // keep track of which pins should be driven high during high part of pwm
volatile uint8_t phaseOutputsDHighInv = 0; // keep track of which pins should be driven high during high part of pwm

volatile uint8_t phaseOutputsELowInv = 0; // keep track of which pins should be driven high during low part of pwm
volatile uint8_t phaseOutputsFLowInv = 0; // keep track of which pins should be driven high during low part of pwm
volatile uint8_t phaseOutputsDLowInv = 0; // keep track of which pins should be driven high during low part of pwm

// PORTE - phaseOutputs[0];
// PORTF - phaseOutputs[1];
// PORTD - phaseOutputs[2];

//~ PORTE:
	//~ AH1
	//~ AL1
	//~ BH1
	//~ BL1
	//~ CH1
	//~ CL1
	//~ AH2
	//~ AL2
//~ 
//~ PORTF:
	//~ BH2
	//~ BL2
	//~ CH2
	//~ CL2
	//~ AH3
	//~ AL3
	//~ BH3
	//~ BL3
//~ 
//~ PORTD:
	//~ CH3
	//~ CL3
	//~ AH4
	//~ AL4
	//~ BH4
	//~ BL4
	//~ CH4
	//~ CL4
	
void cycle(uint16_t stepDelay) {
	SET_PHASE_STATE_1_MOT2();
	TCD0.CNT = 0;
	while (TCD0.CNT < stepDelay) {}
		
	SET_PHASE_STATE_2_MOT2();
	TCD0.CNT = 0;
	while (TCD0.CNT < stepDelay) {}
		
	SET_PHASE_STATE_3_MOT2();
	TCD0.CNT = 0;
	while (TCD0.CNT < stepDelay) {}
		
	SET_PHASE_STATE_4_MOT2();
	TCD0.CNT = 0;
	while (TCD0.CNT < stepDelay) {}
		
	SET_PHASE_STATE_5_MOT2();
	TCD0.CNT = 0;
	while (TCD0.CNT < stepDelay) {}
		
	SET_PHASE_STATE_6_MOT2();
	TCD0.CNT = 0;
	while (TCD0.CNT < stepDelay) {}
}

int main (void) {
	configClock ();
	//~ initUarts ();
	//~ stdout = &debug;
	
	PORTE.DIR = 0b11000000;
	PORTF.DIR = 0b00001111;
	
	configPWM (&TCF0, &HIRESF, 5000);
	configHalfPWMTimer (&TCE0, &HIRESF, 5000);
	
	configMotTimer(&TCC1); // Motor 1
	configMotTimer(&TCD1); // Motor 2
	configMotTimer(&TCE1); // Motor 3
	configMotTimer(&TCF1); // Motor 4
	
	//~ configDelayTimer (&TCC0);
	//~ adcOffsetA = initAdc (&ADCA);
	//~ adcOffsetB = initAdc (&ADCB);
	
	sei();
	
	TCF0.CCABUF = STARTUP_PWM;
	TCF0.CCBBUF = STARTUP_PWM;
	TCF0.CCCBUF = STARTUP_PWM;
	TCF0.CCDBUF = STARTUP_PWM;
	
	TCE0.CCABUF = STARTUP_PWM/2;
	TCE0.CCBBUF = STARTUP_PWM/2;
	TCE0.CCCBUF = STARTUP_PWM/2;
	TCE0.CCDBUF = STARTUP_PWM/2;

	TC_SetPeriod (&TCD0, (uint16_t)65535); // set TCC0 period
	TC0_ConfigWGM (&TCD0, TC_WGMODE_NORMAL_gc); // normal timer countermode
	TC0_ConfigClockSource (&TCD0, TC_CLKSEL_DIV1024_gc);
		
	uint16_t stepDelay = 400;
	cycle(stepDelay);
	stepDelay = 200;
	cycle(stepDelay);
	//~ stepDelay = 100;
	//~ cycle(stepDelay);
	//~ stepDelay = 50;
	//~ cycle(stepDelay);
	//~ stepDelay = 30;
	//~ cycle(stepDelay);
	
	while (1) {
		cycle(stepDelay);
	}
	
}

void configClock (void) {
	// enable 32mhz oscillator 
	CLKSYS_Enable( OSC_RC32MEN_bm );
	do {} while ( CLKSYS_IsReady( OSC_RC32MRDY_bm ) == 0 );

	// configure pll source = 32mhz oscillator/4 * 16 = 4*32mhz = 128mhz output
	CLKSYS_PLL_Config( OSC_PLLSRC_RC32M_gc, 16 );

	// enable pll
	CLKSYS_Enable( OSC_PLLEN_bm );
	do {} while ( CLKSYS_IsReady( OSC_PLLEN_bm ) == 0 );

	// enable prescale by 2 and 2 again to generate 2x and 4x clocks
	CCP = CCP_IOREG_gc;
	CLK.PSCTRL = CLK_PSBCDIV_2_2_gc;

	// select main clock source as pll output
	CLKSYS_Main_ClockSource_Select( CLK_SCLKSEL_PLL_gc );
	
	// output clock on port d pin 7
	//~ PORTCFG.CLKEVOUT = PORTCFG_CLKOUT_PD7_gc; 
}

static void initUarts (void) {
    // Set the TxD pin high - set PORTD DIR register bit 3 to 1
    PORTC.OUTSET = PIN3_bm;
 
    // Set the TxD pin as an output - set PORTD OUT register bit 3 to 1
    PORTC.DIRSET = PIN3_bm;
 
    // BSEL = 51 so at 32mhz clock, baud rate should be 38400
	
    USARTC0.BAUDCTRLB = 0;			// BSCALE = 0 as well
    USARTC0.BAUDCTRLA = 51;
 
    // Set mode of operation
    USARTC0.CTRLA = 0;				// no interrupts please
    USARTC0.CTRLC = 0x03;			// async, no parity, 8 bit data, 1 stop bit
 
    // Enable transmitter only
    USARTC0.CTRLB = USART_TXEN_bm;
}

// Configures PWM output on compare a b and c for single slope pwm, with hires, and clk source as sys clk
void configPWM (volatile TC0_t * tc, HIRES_t * hires, uint16_t period) {
	TC_SetPeriod (tc, period );
	TC0_ConfigWGM (tc, TC_WGMODE_NORMAL_gc ); // set to single slope pwm generation mode
	TC0_EnableCCChannels (tc, TC0_CCAEN_bm); // enable compare A
	TC0_EnableCCChannels (tc, TC0_CCBEN_bm); // enable compare B
	TC0_EnableCCChannels (tc, TC0_CCCEN_bm); // enable compare C
	TC0_EnableCCChannels (tc, TC0_CCDEN_bm); // enable compare D

	TC0_SetCCAIntLevel (tc, TC_CCAINTLVL_HI_gc);
	TC0_SetCCBIntLevel (tc, TC_CCBINTLVL_HI_gc);
	TC0_SetCCCIntLevel (tc, TC_CCCINTLVL_HI_gc);
	TC0_SetCCDIntLevel (tc, TC_CCDINTLVL_HI_gc);

	TC0_SetOverflowIntLevel (tc, TC_OVFINTLVL_HI_gc);
	
	PMIC.CTRL |= PMIC_HILVLEN_bm;

	TC0_ConfigClockSource (tc, TC_CLKSEL_DIV1_gc);
	HIRES_Enable (hires, HIRES_HREN_TC0_gc);
}

// Configures PWM output on compare a b and c for single slope pwm, with hires, and clk source as sys clk
void configHalfPWMTimer (volatile TC0_t * tc, HIRES_t * hires, uint16_t period) {
	TC_SetPeriod (tc, period );
	TC0_ConfigWGM (tc, TC_WGMODE_NORMAL_gc ); // set to single slope pwm generation mode
	TC0_EnableCCChannels (tc, TC0_CCAEN_bm); // enable compare A
	TC0_EnableCCChannels (tc, TC0_CCBEN_bm); // enable compare B
	TC0_EnableCCChannels (tc, TC0_CCCEN_bm); // enable compare C
	TC0_EnableCCChannels (tc, TC0_CCDEN_bm); // enable compare D

	TC0_SetCCAIntLevel (tc, TC_CCAINTLVL_HI_gc);
	TC0_SetCCBIntLevel (tc, TC_CCBINTLVL_HI_gc);
	TC0_SetCCCIntLevel (tc, TC_CCCINTLVL_HI_gc);
	TC0_SetCCDIntLevel (tc, TC_CCDINTLVL_HI_gc);
	
	PMIC.CTRL |= PMIC_HILVLEN_bm;

	TC0_ConfigClockSource (tc, TC_CLKSEL_DIV1_gc);
	HIRES_Enable (hires, HIRES_HREN_TC0_gc);
}

void configMotTimer (volatile TC0_t * tc) {
	TC_SetPeriod (tc, (uint16_t)65535); // set TCC0 period
	TC0_ConfigWGM (tc, TC_WGMODE_NORMAL_gc); // normal timer countermode
	TC0_ConfigClockSource (tc, TC_CLKSEL_DIV1024_gc);
	
	//~ TC0_EnableCCChannels (tc, TC0_CCAEN_bm); // enable compare A
	PMIC.CTRL |= PMIC_HILVLEN_bm;
}

void configDelayTimer (volatile TC0_t * tc) {
	TC_SetPeriod (tc, 1000 ); // set TCC0 period
	TC0_ConfigWGM (tc, TC_WGMODE_NORMAL_gc);

	TC0_ConfigClockSource (tc, TC_CLKSEL_OFF_gc);
}

// use these to set duty cycle:

// TCF0.CCABUF = value
// TCF0.CCBBUF = value
// TCF0.CCCBUF = value
// TCF0.CCDBUF = value



// 8 bit, Unsigned, Single Ended, 125khz
// ref = vcc/1.6 = 3.3v/1.6 = 2.0625v
// 1X Gain
// Initialize to channels pins 0,1,2,3 on channels 0,1,2,3

int8_t initAdc (ADC_t * adc) {
	ADC_CalibrationValues_Load (adc);
  	ADC_ConvMode_and_Resolution_Config (adc, ADC_ConvMode_Signed, ADC_RESOLUTION_8BIT_gc);
	ADC_Prescaler_Config (adc, ADC_PRESCALER_DIV256_gc); // Fadc = 125khz
	ADC_Reference_Config (adc, ADC_REFSEL_VCC_gc); // vref = vcc/1.6

   	/* Get offset value */
   	
	ADC_Ch_InputMode_and_Gain_Config (&(adc->CH0),
	                                 ADC_CH_INPUTMODE_DIFF_gc,
	                                 ADC_CH_GAIN_1X_gc);

   	ADC_Ch_InputMux_Config (&(adc->CH0), ADC_CH_MUXPOS_PIN1_gc, ADC_CH_MUXNEG_PIN1_gc);
	ADC_Enable (adc);
	ADC_Wait_32MHz (adc); // Wait until common mode voltage is stable.
 	int8_t offset = ADC_Offset_Get_Signed (&ADCA, &ADCA.CH0, false);
    ADC_Disable (adc);
    
    ADC_ConvMode_and_Resolution_Config (adc, ADC_ConvMode_Unsigned, ADC_RESOLUTION_8BIT_gc);
    
    /* Setup channel 0, 1, 2 and 3 to have single ended input and 1x gain. */
	ADC_Ch_InputMode_and_Gain_Config (&(adc->CH0),
	                                 ADC_CH_INPUTMODE_SINGLEENDED_gc,
	                                 ADC_CH_GAIN_1X_gc);

	ADC_Ch_InputMode_and_Gain_Config (&(adc->CH1),
	                                 ADC_CH_INPUTMODE_SINGLEENDED_gc,
	                                 ADC_CH_GAIN_1X_gc);

	ADC_Ch_InputMode_and_Gain_Config (&(adc->CH2),
	                                 ADC_CH_INPUTMODE_SINGLEENDED_gc,
	                                 ADC_CH_GAIN_1X_gc);

	ADC_Ch_InputMode_and_Gain_Config (&(adc->CH3),
	                                 ADC_CH_INPUTMODE_SINGLEENDED_gc,
	                                 ADC_CH_GAIN_1X_gc);
    
	/* Set input to the channels to be PIN 0, 1, 2 and 3. */
	ADC_Ch_InputMux_Config (&(adc->CH0), ADC_CH_MUXPOS_PIN0_gc, ADC_CH_MUXPOS_PIN0_gc);
	ADC_Ch_InputMux_Config (&(adc->CH1), ADC_CH_MUXPOS_PIN1_gc, ADC_CH_MUXPOS_PIN1_gc);
	ADC_Ch_InputMux_Config (&(adc->CH2), ADC_CH_MUXPOS_PIN2_gc, ADC_CH_MUXPOS_PIN2_gc);
	ADC_Ch_InputMux_Config (&(adc->CH3), ADC_CH_MUXPOS_PIN3_gc, ADC_CH_MUXPOS_PIN3_gc);
	samplingGroup = 0; // Keep trak of which group of pins this adc is sampling from.  Start with group 0 (pins 0,1,2,3)

	ADC_SweepChannels_Config (adc, ADC_SWEEP_0123_gc); // Setup sweep of all four virtual channels.

	/* Enable low level sample complete interrupt for all 4 channels */
	ADC_Ch_Interrupts_Config (&(adc->CH0), ADC_CH_INTMODE_COMPLETE_gc, ADC_CH_INTLVL_HI_gc);
	ADC_Ch_Interrupts_Config (&(adc->CH1), ADC_CH_INTMODE_COMPLETE_gc, ADC_CH_INTLVL_HI_gc);
	ADC_Ch_Interrupts_Config (&(adc->CH2), ADC_CH_INTMODE_COMPLETE_gc, ADC_CH_INTLVL_HI_gc);
	ADC_Ch_Interrupts_Config (&(adc->CH3), ADC_CH_INTMODE_COMPLETE_gc, ADC_CH_INTLVL_HI_gc);

	PMIC.CTRL |= PMIC_HILVLEN_bm; // Enable low level interrupts
	ADC_Enable (adc); // Enable ADC A with free running mode
	ADC_Wait_32MHz (adc); // Wait until common mode voltage is stable
	ADC_FreeRunning_Enable (adc); // Enable free running mode
	
	return offset;
}

ISR(ADCA_CH0_vect) {
	ADCA.CH0.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	if (samplingGroup == 0)
		senseValues[0] = ADCA.CH0.RES-adcOffsetA;
	else
		senseValues[4] = ADCA.CH0.RES-adcOffsetA;
}

ISR(ADCA_CH1_vect) {
	ADCA.CH1.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	if (samplingGroup == 0)
		senseValues[1] = ADCA.CH1.RES-adcOffsetA;
	else
		senseValues[5] = ADCA.CH1.RES-adcOffsetA;
}

ISR(ADCA_CH2_vect) {
	ADCA.CH2.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	if (samplingGroup == 0)
		senseValues[2] = ADCA.CH2.RES-adcOffsetA;
	else
		senseValues[6] = ADCA.CH2.RES-adcOffsetA;
}

ISR(ADCA_CH3_vect) {
	ADCA.CH3.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	if (samplingGroup == 0)
		senseValues[3] = ADCA.CH3.RES-adcOffsetA;
	else
		senseValues[7] = ADCA.CH3.RES-adcOffsetA;
	
	// Flip between sampling groups for adcA, because we need to sample all 8 pins and there are only 4 adc channels
	if (samplingGroup == 0) {
		// Set input to the channels in ADC A to be PIN 4, 5, 6 and 7
		ADC_Ch_InputMux_Config(&(ADCA.CH0), ADC_CH_MUXPOS_PIN4_gc, ADC_CH_MUXPOS_PIN4_gc);
		ADC_Ch_InputMux_Config(&(ADCA.CH1), ADC_CH_MUXPOS_PIN5_gc, ADC_CH_MUXPOS_PIN5_gc);
		ADC_Ch_InputMux_Config(&(ADCA.CH2), ADC_CH_MUXPOS_PIN6_gc, ADC_CH_MUXPOS_PIN6_gc);
		ADC_Ch_InputMux_Config(&(ADCA.CH3), ADC_CH_MUXPOS_PIN7_gc, ADC_CH_MUXPOS_PIN7_gc);
		samplingGroup = 1; // keep track of sampleingGroup.  Group 1 = Pins 4,5,6,7
	} else {
		// Set input to the channels in ADC A to be PIN 0, 1, 2 and 3
		ADC_Ch_InputMux_Config(&(ADCA.CH0), ADC_CH_MUXPOS_PIN0_gc, ADC_CH_MUXPOS_PIN0_gc);
		ADC_Ch_InputMux_Config(&(ADCA.CH1), ADC_CH_MUXPOS_PIN1_gc, ADC_CH_MUXPOS_PIN1_gc);
		ADC_Ch_InputMux_Config(&(ADCA.CH2), ADC_CH_MUXPOS_PIN2_gc, ADC_CH_MUXPOS_PIN2_gc);
		ADC_Ch_InputMux_Config(&(ADCA.CH3), ADC_CH_MUXPOS_PIN3_gc, ADC_CH_MUXPOS_PIN3_gc);
		samplingGroup = 0; // keep track of sampleingGroup.  Group 1 = Pins 0,1,2,3
	}
}

ISR(ADCB_CH0_vect) {
	ADCB.CH0.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	senseValues[8] = ADCB.CH0.RES-adcOffsetB;
}

ISR(ADCB_CH1_vect) {
	ADCB.CH1.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	senseValues[9] = ADCB.CH1.RES-adcOffsetB;
}

ISR(ADCB_CH2_vect) {
	ADCB.CH2.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	senseValues[10] = ADCB.CH2.RES-adcOffsetB;
}

ISR(ADCB_CH3_vect) {
	ADCB.CH3.INTFLAGS = ADC_CH_CHIF_bm; // Clear interrupt flag
	senseValues[11] = ADCB.CH3.RES-adcOffsetB;
}

// When TCF0 compare interrupts are triggered, turn off the set of 6 outputs which
// controls the phase assigned to that interrupt

ISR (TCF0_CCA_vect) {	
	// motor 1 on pe0-5
	
	// force bits 6 and 7 to 1 (for phaseOutputsEHighInv) and 0 (for phaseOutputsEHighInv) so that only pins for motor 1 are turned off 
	PORTE.OUT &= (phaseOutputsEHighInv | 0b11000000); // turn off all high bits in phaseOutputsELowInv
	PORTE.OUT |= (phaseOutputsELow & 0b00111111); // turn on all low bits in phaseOutputsEHigh	
}

ISR (TCF0_CCB_vect) {
	// motor 2 on pe6-7 and pf0-3
	
	PORTE.OUT &= (phaseOutputsEHighInv | 0b00111111); // turn off all high bits in phaseOutputsELowInv
	PORTE.OUT |= (phaseOutputsELow & 0b11000000); // turn on all low bits in phaseOutputsEHigh	
	
	PORTF.OUT &= (phaseOutputsFHighInv | 0b11110000); // turn off all high bits in phaseOutputsELowInv
	PORTF.OUT |= (phaseOutputsFLow & 0b00001111); // turn on all low bits in phaseOutputsEHigh	
}

ISR (TCF0_CCC_vect) {
	// motor 3 on pf4-7 and pd0-1
	
	PORTF.OUT &= (phaseOutputsFHighInv | 0b00001111); // turn off all high bits in phaseOutputsELowInv
	PORTF.OUT |= (phaseOutputsFLow & 0b11110000); // turn on all low bits in phaseOutputsEHigh	
	
	PORTD.OUT &= (phaseOutputsDHighInv | 0b11111100); // turn off all high bits in phaseOutputsELowInv
	PORTD.OUT |= (phaseOutputsDLow & 0b00000011); // turn on all low bits in phaseOutputsEHigh	
}

ISR (TCF0_CCD_vect) {
	// motor 4 on pd2-7
	
	PORTD.OUT &= (phaseOutputsDHighInv | 0b00000011); // turn off all high bits in phaseOutputsELowInv
	PORTD.OUT |= (phaseOutputsDLow & 0b11111100); // turn on all low bits in phaseOutputsEHigh	
}

// When TCF0 overflows, set all phase outputs to their commutation value
ISR (TCF0_OVF_vect) {
	PORTE.OUT &= phaseOutputsELowInv; // turn off all low bits in phaseOutputsELowInv
	PORTE.OUT |= phaseOutputsEHigh; // turn on all high bits in phaseOutputsEHigh
	PORTF.OUT &= phaseOutputsFLowInv; // turn off all low bits in phaseOutputsFLowInv
	PORTF.OUT |= phaseOutputsFHigh; // turn on all high bits in phaseOutputsFHigh
	PORTD.OUT &= phaseOutputsDLowInv; // turn off all low bits in phaseOutputsDLowInv
	PORTD.OUT |= phaseOutputsDHigh; // turn on all high bits in phaseOutputsDHigh
}

ISR (TCE0_CCA_vect) {
	// half way into high part of motor 1 pwm
	// read and respond to adc sample
}

ISR (TCE0_CCB_vect) {
	// half way into high part of motor 2 pwm
	// read and respond to adc sample
	if (stateSlope[motor1State]) { // rising
		if (senseValues[motor1State] > motor2Thresh) {
			// set timer to trigger next phase
		}
	} else { // falling
		if (senseValues[motor1State] < motor2Thresh) {
			// set timer to trigger next phase
		}
	}
}

ISR (TCE0_CCC_vect) {
	// half way into high part of motor 3 pwm
	// read and respond to adc sample
}

ISR (TCE0_CCD_vect) {
	// half way into high part of motor 4 pwm
	// read and respond to adc sample
}

ISR (TCD1_CCA_vect) {
	// time to change motor2 state
	TCD1.CNT = 0;
	TCD1.CCABUF = 60000;
	if (motor2State < 5)
		motor2State++;
	else
		motor2State=0;
	setMotor2State(motor2State);
}

static int putcharDebug (char c, FILE *stream) {
	if (c == '\n')
		putcharDebug('\r', stream);
 
    // Wait for the transmit buffer to be empty
    while ( !( USARTC0.STATUS & USART_DREIF_bm) );
 
    // Put our character into the transmit buffer
    USARTC0.DATA = c; 
 
    return 0;
}
